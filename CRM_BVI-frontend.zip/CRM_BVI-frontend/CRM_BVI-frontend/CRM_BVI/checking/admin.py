from django.contrib import admin
from .models import Abiturients, Olimpiads, Directions

admin.site.register(Abiturients)
admin.site.register(Olimpiads)
admin.site.register(Directions)